import React, { ReactNode } from 'react';

interface CalmCardProps {
  children: ReactNode;
  onClick?: () => void;
  color?: 'blue' | 'green' | 'yellow' | 'purple' | 'pink';
}

export function CalmCard({ children, onClick, color = 'blue' }: CalmCardProps) {
  const colors = {
    blue: 'bg-gradient-to-br from-blue-100 to-blue-200 shadow-[0_6px_20px_rgba(191,219,254,0.5)]',
    green: 'bg-gradient-to-br from-green-100 to-green-200 shadow-[0_6px_20px_rgba(187,247,208,0.5)]',
    yellow: 'bg-gradient-to-br from-yellow-100 to-yellow-200 shadow-[0_6px_20px_rgba(254,240,138,0.5)]',
    purple: 'bg-gradient-to-br from-purple-100 to-purple-200 shadow-[0_6px_20px_rgba(233,213,255,0.5)]',
    pink: 'bg-gradient-to-br from-pink-100 to-pink-200 shadow-[0_6px_20px_rgba(252,231,243,0.5)]',
  };

  return (
    <div
      onClick={onClick}
      className={`
        ${colors[color]}
        p-6 rounded-3xl
        ${onClick ? 'cursor-pointer hover:shadow-[0_8px_24px_rgba(191,219,254,0.7)]' : ''}
      `}
    >
      {children}
    </div>
  );
}
