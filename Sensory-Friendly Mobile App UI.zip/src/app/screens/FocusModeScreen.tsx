import React, { useState } from 'react';
import { Header } from '../components/Header';
import { CalmCard } from '../components/CalmCard';
import { CalmButton } from '../components/CalmButton';

interface FocusModeScreenProps {
  onBack: () => void;
}

export function FocusModeScreen({ onBack }: FocusModeScreenProps) {
  const [isActive, setIsActive] = useState(false);
  const [duration, setDuration] = useState(25);

  const durations = [
    { value: 15, label: '15 min', emoji: '⏱️' },
    { value: 25, label: '25 min', emoji: '⏰' },
    { value: 45, label: '45 min', emoji: '🕐' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🎯</div>
          <h2 className="text-3xl text-gray-700 mb-2">Focus Mode</h2>
          <p className="text-lg text-gray-600">Stay focused, gently</p>
        </div>
        
        <div className="max-w-md mx-auto space-y-6">
          {!isActive ? (
            <>
              <CalmCard color="blue">
                <p className="text-lg text-gray-700 mb-4 text-center">
                  Choose your focus duration:
                </p>
                <div className="grid grid-cols-3 gap-3">
                  {durations.map((d) => (
                    <button
                      key={d.value}
                      onClick={() => setDuration(d.value)}
                      className={`
                        py-4 rounded-2xl text-center
                        ${duration === d.value
                          ? 'bg-blue-300 shadow-lg'
                          : 'bg-white shadow-md'
                        }
                      `}
                    >
                      <div className="text-2xl mb-1">{d.emoji}</div>
                      <div className="text-base text-gray-700">{d.label}</div>
                    </button>
                  ))}
                </div>
              </CalmCard>
              
              <CalmButton onClick={() => setIsActive(true)} variant="primary" fullWidth>
                Start Focus Session 🌟
              </CalmButton>
            </>
          ) : (
            <>
              <CalmCard color="green">
                <div className="text-center py-8">
                  <div className="text-7xl mb-6">✨</div>
                  <p className="text-4xl text-gray-700 mb-4">{duration}:00</p>
                  <p className="text-xl text-gray-600">Focus in progress...</p>
                </div>
              </CalmCard>
              
              <CalmButton onClick={() => setIsActive(false)} variant="warning" fullWidth>
                End Session 🛑
              </CalmButton>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
