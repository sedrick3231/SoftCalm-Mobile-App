import React from 'react';
import { Header } from '../components/Header';
import { CalmCard } from '../components/CalmCard';

interface RelaxationModeScreenProps {
  onBack: () => void;
}

export function RelaxationModeScreen({ onBack }: RelaxationModeScreenProps) {
  const techniques = [
    { id: 1, title: 'Deep Breathing', description: 'Breathe slowly and deeply', emoji: '🫁', color: 'blue' as const },
    { id: 2, title: 'Progressive Relaxation', description: 'Release muscle tension', emoji: '💆', color: 'green' as const },
    { id: 3, title: 'Visualization', description: 'Imagine peaceful scenes', emoji: '🌄', color: 'purple' as const },
    { id: 4, title: 'Body Scan', description: 'Notice sensations gently', emoji: '✨', color: 'pink' as const },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🌿</div>
          <h2 className="text-3xl text-gray-700 mb-2">Relaxation Mode</h2>
          <p className="text-lg text-gray-600">Find your peace</p>
        </div>
        
        <div className="max-w-md mx-auto space-y-4">
          {techniques.map((technique) => (
            <CalmCard key={technique.id} color={technique.color}>
              <div className="flex items-start gap-4">
                <span className="text-5xl">{technique.emoji}</span>
                <div className="flex-1">
                  <h3 className="text-xl text-gray-700 mb-2">{technique.title}</h3>
                  <p className="text-base text-gray-600">{technique.description}</p>
                </div>
              </div>
            </CalmCard>
          ))}
        </div>
      </div>
    </div>
  );
}
