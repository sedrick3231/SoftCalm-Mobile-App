import React, { useState } from 'react';
import { Header } from '../components/Header';
import { CalmCard } from '../components/CalmCard';

interface AccessibilitySettingsScreenProps {
  onBack: () => void;
}

export function AccessibilitySettingsScreen({ onBack }: AccessibilitySettingsScreenProps) {
  const [textSize, setTextSize] = useState(100);
  const [reducedMotion, setReducedMotion] = useState(true);
  const [highContrast, setHighContrast] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">♿</div>
          <h2 className="text-3xl text-gray-700 mb-2">Accessibility</h2>
          <p className="text-lg text-gray-600">Personalize for your needs</p>
        </div>
        
        <div className="max-w-md mx-auto space-y-6">
          <CalmCard color="blue">
            <p className="text-lg text-gray-700 mb-4">
              Text Size: {textSize}%
            </p>
            <input
              type="range"
              min="80"
              max="150"
              value={textSize}
              onChange={(e) => setTextSize(Number(e.target.value))}
              className="w-full h-3 rounded-full bg-white appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, #C8E6F5 0%, #C8E6F5 ${(textSize - 80) / 0.7}%, #fff ${(textSize - 80) / 0.7}%, #fff 100%)`,
              }}
            />
            <div className="flex justify-between mt-2 text-sm text-gray-600">
              <span>Smaller</span>
              <span>Larger</span>
            </div>
          </CalmCard>
          
          <CalmCard color="green">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-xl text-gray-700 mb-2">🎬 Reduced Motion</p>
                <p className="text-base text-gray-600">
                  Minimize animations
                </p>
              </div>
              <button
                onClick={() => setReducedMotion(!reducedMotion)}
                className={`
                  w-16 h-9 rounded-full p-1
                  ${reducedMotion ? 'bg-green-300' : 'bg-gray-300'}
                `}
              >
                <div
                  className={`
                    w-7 h-7 rounded-full bg-white shadow-md
                    transition-transform duration-200
                    ${reducedMotion ? 'translate-x-7' : 'translate-x-0'}
                  `}
                />
              </button>
            </div>
          </CalmCard>
          
          <CalmCard color="purple">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-xl text-gray-700 mb-2">◐ High Contrast</p>
                <p className="text-base text-gray-600">
                  Increase visibility
                </p>
              </div>
              <button
                onClick={() => setHighContrast(!highContrast)}
                className={`
                  w-16 h-9 rounded-full p-1
                  ${highContrast ? 'bg-purple-300' : 'bg-gray-300'}
                `}
              >
                <div
                  className={`
                    w-7 h-7 rounded-full bg-white shadow-md
                    transition-transform duration-200
                    ${highContrast ? 'translate-x-7' : 'translate-x-0'}
                  `}
                />
              </button>
            </div>
          </CalmCard>
          
          <CalmCard color="yellow">
            <div className="text-center py-6">
              <p className="text-lg text-gray-700 mb-3">
                💙 Built for Everyone
              </p>
              <p className="text-base text-gray-600 leading-relaxed">
                These settings help make Soft Calm accessible and comfortable for all users.
              </p>
            </div>
          </CalmCard>
        </div>
      </div>
    </div>
  );
}
