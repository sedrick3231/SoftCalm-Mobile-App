import React from 'react';
import { Header } from '../components/Header';
import { CalmCard } from '../components/CalmCard';
import { useSensory } from '../context/SensoryContext';

interface SoundControlScreenProps {
  onBack: () => void;
}

export function SoundControlScreen({ onBack }: SoundControlScreenProps) {
  const { settings, toggleSound } = useSensory();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🔊</div>
          <h2 className="text-3xl text-gray-700 mb-2">Sound Control</h2>
          <p className="text-lg text-gray-600">Manage audio feedback</p>
        </div>
        
        <div className="max-w-md mx-auto space-y-6">
          <CalmCard color="blue">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-xl text-gray-700 mb-2">🔔 Sound Feedback</p>
                <p className="text-base text-gray-600">
                  Enable gentle sound cues
                </p>
              </div>
              <button
                onClick={toggleSound}
                className={`
                  w-16 h-9 rounded-full p-1
                  ${settings.soundEnabled ? 'bg-green-300' : 'bg-gray-300'}
                `}
              >
                <div
                  className={`
                    w-7 h-7 rounded-full bg-white shadow-md
                    transition-transform duration-200
                    ${settings.soundEnabled ? 'translate-x-7' : 'translate-x-0'}
                  `}
                />
              </button>
            </div>
          </CalmCard>
          
          <CalmCard color="yellow">
            <div className="text-center py-8">
              <p className="text-lg text-gray-700 mb-3">
                💡 Sound Tips
              </p>
              <p className="text-base text-gray-600 leading-relaxed">
                All sounds in this app are optional and gentle. You have complete control.
              </p>
            </div>
          </CalmCard>
          
          <CalmCard color="green">
            <div className="text-center">
              <p className="text-lg text-gray-700 mb-2">
                Current Status: {settings.soundEnabled ? 'On 🔊' : 'Off 🔇'}
              </p>
              <p className="text-base text-gray-600">
                {settings.soundEnabled 
                  ? 'Gentle sounds are enabled'
                  : 'Complete silence mode'}
              </p>
            </div>
          </CalmCard>
        </div>
      </div>
    </div>
  );
}
