import React, { useState } from 'react';
import { Header } from '../components/Header';
import { CalmCard } from '../components/CalmCard';

interface EmergencyCalmScreenProps {
  onBack: () => void;
}

export function EmergencyCalmScreen({ onBack }: EmergencyCalmScreenProps) {
  const [breathCount, setBreathCount] = useState(0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 to-blue-100">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="max-w-md mx-auto space-y-8">
          <CalmCard color="purple">
            <div className="text-center py-12">
              <div className="text-8xl mb-6">🌙</div>
              <h2 className="text-3xl text-gray-700 mb-4">
                You are safe
              </h2>
              <p className="text-xl text-gray-600 leading-relaxed">
                This moment will pass. You've got this.
              </p>
            </div>
          </CalmCard>
          
          <CalmCard color="blue">
            <div className="text-center py-8">
              <p className="text-2xl text-gray-700 mb-6">
                Breathe with me 🫁
              </p>
              <button
                onClick={() => setBreathCount(breathCount + 1)}
                className="w-32 h-32 rounded-full bg-gradient-to-br from-blue-200 to-blue-300 shadow-lg text-4xl"
              >
                {breathCount}
              </button>
              <p className="text-lg text-gray-600 mt-6">
                Tap when you breathe in and out
              </p>
            </div>
          </CalmCard>
          
          <CalmCard color="green">
            <div className="py-6 space-y-4 text-lg text-gray-700 leading-relaxed">
              <p>🌸 You are here now</p>
              <p>💙 You are doing your best</p>
              <p>✨ This feeling is temporary</p>
              <p>🌈 You are stronger than you know</p>
            </div>
          </CalmCard>
          
          <CalmCard color="pink">
            <div className="text-center py-6">
              <p className="text-lg text-gray-700 mb-3">
                🆘 Need More Help?
              </p>
              <p className="text-base text-gray-600 leading-relaxed">
                If you're in crisis, please reach out to a mental health professional or crisis hotline in your area.
              </p>
            </div>
          </CalmCard>
        </div>
      </div>
    </div>
  );
}
