import React, { useState } from 'react';
import { Header } from '../components/Header';
import { CalmButton } from '../components/CalmButton';
import { CalmInput } from '../components/CalmInput';
import { useAuth } from '../context/AuthContext';

interface ForgotPasswordScreenProps {
  onBack: () => void;
}

export function ForgotPasswordScreen({ onBack }: ForgotPasswordScreenProps) {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');
  const { resetPassword } = useAuth();

  const handleReset = async () => {
    setError('');
    if (!email) {
      setError('Please enter your email');
      return;
    }
    
    const success = await resetPassword(email);
    if (success) {
      setSent(true);
    } else {
      setError('Failed to send reset email');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🔄</div>
          <h2 className="text-3xl text-gray-700 mb-2">Reset Password</h2>
          <p className="text-lg text-gray-600">We'll send you a reset link</p>
        </div>
        
        <div className="max-w-sm mx-auto space-y-6">
          {!sent ? (
            <>
              <CalmInput
                type="email"
                label="Email"
                placeholder="your@email.com"
                value={email}
                onChange={setEmail}
              />
              
              {error && (
                <p className="text-center text-red-500 text-lg">{error}</p>
              )}
              
              <CalmButton onClick={handleReset} variant="primary" fullWidth>
                Send Reset Link 📧
              </CalmButton>
            </>
          ) : (
            <div className="text-center py-8">
              <div className="text-6xl mb-4">✅</div>
              <p className="text-xl text-gray-700 mb-4">
                Reset link sent!
              </p>
              <p className="text-lg text-gray-600 mb-6">
                Please check your email for instructions to reset your password.
              </p>
              <CalmButton onClick={onBack} variant="primary" fullWidth>
                Back to Sign In 🔑
              </CalmButton>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
