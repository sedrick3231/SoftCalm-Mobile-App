import React from 'react';
import { Header } from '../components/Header';
import { CalmCard } from '../components/CalmCard';
import { useAuth } from '../context/AuthContext';
import { Heart, Focus, Wind, Home, Volume2, Eye, Settings, Book } from 'lucide-react';

interface HomeScreenProps {
  onNavigate: (screen: string) => void;
}

export function HomeScreen({ onNavigate }: HomeScreenProps) {
  const { user } = useAuth();

  const menuItems = [
    { id: 'calm-activities', label: 'Daily Calm Activities', icon: Heart, color: 'pink' as const, emoji: '💖' },
    { id: 'focus-mode', label: 'Focus Mode', icon: Focus, color: 'blue' as const, emoji: '🎯' },
    { id: 'relaxation-mode', label: 'Relaxation Mode', icon: Wind, color: 'green' as const, emoji: '🌿' },
    { id: 'quiet-space', label: 'Quiet Space', icon: Home, color: 'purple' as const, emoji: '🏠' },
    { id: 'visual-comfort', label: 'Visual Comfort', icon: Eye, color: 'yellow' as const, emoji: '👁️' },
    { id: 'sound-control', label: 'Sound Control', icon: Volume2, color: 'blue' as const, emoji: '🔊' },
    { id: 'mood-tracker', label: 'Mood Tracker', icon: Heart, color: 'pink' as const, emoji: '📊' },
    { id: 'help', label: 'Help & Guidance', icon: Book, color: 'green' as const, emoji: '📚' },
    { id: 'settings', label: 'Settings', icon: Settings, color: 'purple' as const, emoji: '⚙️' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header showBack={false} />
      
      <div className="px-6 py-4">
        <div className="mb-8 text-center">
          <h2 className="text-2xl text-gray-700 mb-2">
            Welcome back, {user?.name || 'Friend'} 🌸
          </h2>
          <p className="text-lg text-gray-600">How can we help you today?</p>
        </div>
        
        <div className="grid grid-cols-1 gap-4 max-w-md mx-auto pb-8">
          {menuItems.map((item) => (
            <CalmCard
              key={item.id}
              color={item.color}
              onClick={() => onNavigate(item.id)}
            >
              <div className="flex items-center gap-4">
                <span className="text-4xl">{item.emoji}</span>
                <span className="text-xl text-gray-700">{item.label}</span>
              </div>
            </CalmCard>
          ))}
        </div>
      </div>
    </div>
  );
}
