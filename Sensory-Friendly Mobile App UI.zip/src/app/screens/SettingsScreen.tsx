import React from 'react';
import { Header } from '../components/Header';
import { CalmCard } from '../components/CalmCard';
import { CalmButton } from '../components/CalmButton';
import { useAuth } from '../context/AuthContext';

interface SettingsScreenProps {
  onBack: () => void;
  onNavigate: (screen: string) => void;
}

export function SettingsScreen({ onBack, onNavigate }: SettingsScreenProps) {
  const { logout, user } = useAuth();

  const handleLogout = () => {
    logout();
    onNavigate('welcome');
  };

  const settingsOptions = [
    { id: 'sensory-comfort', label: 'Sensory Comfort Mode', emoji: '🎚️', color: 'purple' as const },
    { id: 'visual-comfort', label: 'Visual Comfort', emoji: '👁️', color: 'blue' as const },
    { id: 'sound-control', label: 'Sound Control', emoji: '🔊', color: 'green' as const },
    { id: 'notifications-control', label: 'Notifications', emoji: '🔔', color: 'yellow' as const },
    { id: 'accessibility', label: 'Accessibility Settings', emoji: '♿', color: 'pink' as const },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">⚙️</div>
          <h2 className="text-3xl text-gray-700 mb-2">Settings</h2>
          <p className="text-lg text-gray-600">Customize your experience</p>
        </div>
        
        <div className="max-w-md mx-auto space-y-4">
          <CalmCard color="blue">
            <div className="text-center py-4">
              <p className="text-lg text-gray-700 mb-2">
                👤 Signed in as
              </p>
              <p className="text-base text-gray-600">
                {user?.email || 'Guest'}
              </p>
            </div>
          </CalmCard>
          
          {settingsOptions.map((option) => (
            <CalmCard
              key={option.id}
              color={option.color}
              onClick={() => onNavigate(option.id)}
            >
              <div className="flex items-center gap-4">
                <span className="text-4xl">{option.emoji}</span>
                <span className="text-xl text-gray-700">{option.label}</span>
              </div>
            </CalmCard>
          ))}
          
          <div className="pt-4">
            <CalmButton onClick={handleLogout} variant="warning" fullWidth>
              Sign Out 👋
            </CalmButton>
          </div>
        </div>
      </div>
    </div>
  );
}
