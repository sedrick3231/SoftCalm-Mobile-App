import React from 'react';
import { Header } from '../components/Header';
import { CalmCard } from '../components/CalmCard';
import { useSensory } from '../context/SensoryContext';

interface VisualComfortScreenProps {
  onBack: () => void;
}

export function VisualComfortScreen({ onBack }: VisualComfortScreenProps) {
  const { settings, updateBrightness, updateContrast, updateVisualDensity } = useSensory();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">👁️</div>
          <h2 className="text-3xl text-gray-700 mb-2">Visual Comfort</h2>
          <p className="text-lg text-gray-600">Adjust visual settings</p>
        </div>
        
        <div className="max-w-md mx-auto space-y-6">
          <CalmCard color="blue">
            <p className="text-lg text-gray-700 mb-4">
              Brightness: {settings.brightness}%
            </p>
            <input
              type="range"
              min="0"
              max="100"
              value={settings.brightness}
              onChange={(e) => updateBrightness(Number(e.target.value))}
              className="w-full h-3 rounded-full bg-white appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, #C8E6F5 0%, #C8E6F5 ${settings.brightness}%, #fff ${settings.brightness}%, #fff 100%)`,
              }}
            />
            <div className="flex justify-between mt-2 text-sm text-gray-600">
              <span>Dim 🌙</span>
              <span>Bright 🌞</span>
            </div>
          </CalmCard>
          
          <CalmCard color="green">
            <p className="text-lg text-gray-700 mb-4">
              Contrast: {settings.contrast}%
            </p>
            <input
              type="range"
              min="0"
              max="100"
              value={settings.contrast}
              onChange={(e) => updateContrast(Number(e.target.value))}
              className="w-full h-3 rounded-full bg-white appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, #D4F1D4 0%, #D4F1D4 ${settings.contrast}%, #fff ${settings.contrast}%, #fff 100%)`,
              }}
            />
            <div className="flex justify-between mt-2 text-sm text-gray-600">
              <span>Low ◐</span>
              <span>High ●</span>
            </div>
          </CalmCard>
          
          <CalmCard color="purple">
            <p className="text-lg text-gray-700 mb-4">
              Visual Density: {settings.visualDensity}%
            </p>
            <input
              type="range"
              min="0"
              max="100"
              value={settings.visualDensity}
              onChange={(e) => updateVisualDensity(Number(e.target.value))}
              className="w-full h-3 rounded-full bg-white appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, #E9D5FF 0%, #E9D5FF ${settings.visualDensity}%, #fff ${settings.visualDensity}%, #fff 100%)`,
              }}
            />
            <div className="flex justify-between mt-2 text-sm text-gray-600">
              <span>Minimal ▫️</span>
              <span>Normal ▪️</span>
            </div>
          </CalmCard>
        </div>
      </div>
    </div>
  );
}
