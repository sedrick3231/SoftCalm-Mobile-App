import React, { useState } from 'react';
import { Header } from '../components/Header';
import { CalmButton } from '../components/CalmButton';
import { CalmInput } from '../components/CalmInput';
import { useAuth } from '../context/AuthContext';

interface LoginScreenProps {
  onBack: () => void;
  onSuccess: () => void;
  onForgotPassword: () => void;
  onSignUp: () => void;
}

export function LoginScreen({ onBack, onSuccess, onForgotPassword, onSignUp }: LoginScreenProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();

  const handleLogin = async () => {
    setError('');
    if (!email || !password) {
      setError('Please fill in all fields');
      return;
    }
    
    const success = await login(email, password);
    if (success) {
      onSuccess();
    } else {
      setError('Invalid credentials');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🔑</div>
          <h2 className="text-3xl text-gray-700 mb-2">Sign In</h2>
          <p className="text-lg text-gray-600">Welcome back to your peaceful space</p>
        </div>
        
        <div className="max-w-sm mx-auto space-y-6">
          <CalmInput
            type="email"
            label="Email"
            placeholder="your@email.com"
            value={email}
            onChange={setEmail}
          />
          
          <CalmInput
            type="password"
            label="Password"
            placeholder="Enter your password"
            value={password}
            onChange={setPassword}
          />
          
          {error && (
            <p className="text-center text-red-500 text-lg">{error}</p>
          )}
          
          <CalmButton onClick={handleLogin} variant="primary" fullWidth>
            Sign In 🌸
          </CalmButton>
          
          <button
            onClick={onForgotPassword}
            className="w-full text-center text-lg text-blue-600 py-2"
          >
            Forgot Password? 🔄
          </button>
          
          <div className="text-center pt-4">
            <p className="text-lg text-gray-600 mb-3">Don't have an account?</p>
            <CalmButton onClick={onSignUp} variant="secondary" fullWidth>
              Create Account 🌟
            </CalmButton>
          </div>
        </div>
      </div>
    </div>
  );
}
