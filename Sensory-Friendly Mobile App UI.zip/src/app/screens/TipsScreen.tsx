import React from 'react';
import { Header } from '../components/Header';
import { CalmCard } from '../components/CalmCard';

interface TipsScreenProps {
  onBack: () => void;
}

export function TipsScreen({ onBack }: TipsScreenProps) {
  const tips = [
    { 
      id: 1, 
      title: 'Take Breaks', 
      description: 'Step away from screens regularly. Your comfort matters.',
      emoji: '⏸️',
      color: 'blue' as const 
    },
    { 
      id: 2, 
      title: 'Control Your Environment', 
      description: 'Adjust lighting, sounds, and temperature to your needs.',
      emoji: '🌡️',
      color: 'green' as const 
    },
    { 
      id: 3, 
      title: 'Use Comfort Mode', 
      description: 'Our sensory comfort slider helps reduce stimulation instantly.',
      emoji: '🎚️',
      color: 'purple' as const 
    },
    { 
      id: 4, 
      title: 'Practice Grounding', 
      description: '5-4-3-2-1: Name 5 things you see, 4 you hear, 3 you feel, 2 you smell, 1 you taste.',
      emoji: '🧘',
      color: 'pink' as const 
    },
    { 
      id: 5, 
      title: 'Be Patient With Yourself', 
      description: 'Your sensitivity is valid. Progress is not linear.',
      emoji: '💙',
      color: 'yellow' as const 
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">💡</div>
          <h2 className="text-3xl text-gray-700 mb-2">Tips for You</h2>
          <p className="text-lg text-gray-600">Gentle guidance for daily life</p>
        </div>
        
        <div className="max-w-md mx-auto space-y-4">
          {tips.map((tip) => (
            <CalmCard key={tip.id} color={tip.color}>
              <div className="flex items-start gap-4">
                <span className="text-4xl">{tip.emoji}</span>
                <div className="flex-1">
                  <h3 className="text-xl text-gray-700 mb-2">{tip.title}</h3>
                  <p className="text-base text-gray-600 leading-relaxed">{tip.description}</p>
                </div>
              </div>
            </CalmCard>
          ))}
        </div>
      </div>
    </div>
  );
}
