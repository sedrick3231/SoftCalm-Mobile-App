import React, { useEffect } from 'react';

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 2000);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 flex items-center justify-center p-6">
      <div className="text-center">
        <div className="mb-8">
          <div className="text-8xl mb-4">🌸</div>
          <h1 className="text-4xl text-gray-700 mb-2">Soft Calm</h1>
          <p className="text-xl text-gray-500">Your peaceful space</p>
        </div>
      </div>
    </div>
  );
}
