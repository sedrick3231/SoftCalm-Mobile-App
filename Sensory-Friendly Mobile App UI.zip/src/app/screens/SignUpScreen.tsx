import React, { useState } from 'react';
import { Header } from '../components/Header';
import { CalmButton } from '../components/CalmButton';
import { CalmInput } from '../components/CalmInput';
import { useAuth } from '../context/AuthContext';

interface SignUpScreenProps {
  onBack: () => void;
  onSuccess: () => void;
}

export function SignUpScreen({ onBack, onSuccess }: SignUpScreenProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const { signup } = useAuth();

  const handleSignUp = async () => {
    setError('');
    
    if (!name || !email || !password || !confirmPassword) {
      setError('Please fill in all fields');
      return;
    }
    
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    
    const success = await signup(email, password, name);
    if (success) {
      onSuccess();
    } else {
      setError('Sign up failed. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🌟</div>
          <h2 className="text-3xl text-gray-700 mb-2">Create Account</h2>
          <p className="text-lg text-gray-600">Join your peaceful community</p>
        </div>
        
        <div className="max-w-sm mx-auto space-y-6">
          <CalmInput
            type="text"
            label="Name"
            placeholder="Your name"
            value={name}
            onChange={setName}
          />
          
          <CalmInput
            type="email"
            label="Email"
            placeholder="your@email.com"
            value={email}
            onChange={setEmail}
          />
          
          <CalmInput
            type="password"
            label="Password"
            placeholder="Create a password"
            value={password}
            onChange={setPassword}
          />
          
          <CalmInput
            type="password"
            label="Confirm Password"
            placeholder="Confirm your password"
            value={confirmPassword}
            onChange={setConfirmPassword}
          />
          
          {error && (
            <p className="text-center text-red-500 text-lg">{error}</p>
          )}
          
          <CalmButton onClick={handleSignUp} variant="primary" fullWidth>
            Create Account 🌸
          </CalmButton>
        </div>
      </div>
    </div>
  );
}
