import React from 'react';
import { Header } from '../components/Header';
import { CalmCard } from '../components/CalmCard';
import { useSensory } from '../context/SensoryContext';

interface SensoryComfortModeScreenProps {
  onBack: () => void;
}

export function SensoryComfortModeScreen({ onBack }: SensoryComfortModeScreenProps) {
  const { settings, updateComfortLevel } = useSensory();

  const getComfortDescription = () => {
    if (settings.comfortLevel < 25) return { emoji: '🌙', text: 'Ultra Calm - Minimal stimulation', color: 'purple' as const };
    if (settings.comfortLevel < 50) return { emoji: '✨', text: 'Very Calm - Reduced intensity', color: 'blue' as const };
    if (settings.comfortLevel < 75) return { emoji: '🌸', text: 'Moderate - Balanced comfort', color: 'pink' as const };
    return { emoji: '🌞', text: 'Normal - Full experience', color: 'yellow' as const };
  };

  const comfort = getComfortDescription();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🎚️</div>
          <h2 className="text-3xl text-gray-700 mb-2">Sensory Comfort Mode</h2>
          <p className="text-lg text-gray-600">One slider for complete control</p>
        </div>
        
        <div className="max-w-md mx-auto space-y-6">
          <CalmCard color={comfort.color}>
            <div className="text-center py-6">
              <div className="text-7xl mb-4">{comfort.emoji}</div>
              <p className="text-2xl text-gray-700 mb-2">{settings.comfortLevel}%</p>
              <p className="text-lg text-gray-600">{comfort.text}</p>
            </div>
          </CalmCard>
          
          <CalmCard color="blue">
            <p className="text-lg text-gray-700 mb-4 text-center">
              Master Comfort Control
            </p>
            <input
              type="range"
              min="0"
              max="100"
              value={settings.comfortLevel}
              onChange={(e) => updateComfortLevel(Number(e.target.value))}
              className="w-full h-4 rounded-full bg-white appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, #C8E6F5 0%, #C8E6F5 ${settings.comfortLevel}%, #fff ${settings.comfortLevel}%, #fff 100%)`,
              }}
            />
            <div className="flex justify-between mt-3 text-sm text-gray-600">
              <span>0%</span>
              <span>25%</span>
              <span>50%</span>
              <span>75%</span>
              <span>100%</span>
            </div>
          </CalmCard>
          
          <CalmCard color="green">
            <div className="space-y-3">
              <p className="text-lg text-gray-700 mb-3">✨ What This Controls:</p>
              <div className="space-y-2 text-base text-gray-600">
                <p>• 🔆 Brightness: {settings.brightness}%</p>
                <p>• ◐ Contrast: {settings.contrast}%</p>
                <p>• ▪️ Visual Density: {settings.visualDensity}%</p>
              </div>
            </div>
          </CalmCard>
          
          <CalmCard color="yellow">
            <div className="text-center py-4">
              <p className="text-lg text-gray-700 mb-3">
                💡 Unique Feature
              </p>
              <p className="text-base text-gray-600 leading-relaxed">
                This single slider adjusts all sensory settings at once for instant comfort.
              </p>
            </div>
          </CalmCard>
        </div>
      </div>
    </div>
  );
}
