import React, { useState } from 'react';
import { Header } from '../components/Header';
import { CalmButton } from '../components/CalmButton';
import { CalmInput } from '../components/CalmInput';

interface UserProfileSetupScreenProps {
  onBack: () => void;
  onNext: () => void;
}

export function UserProfileSetupScreen({ onBack, onNext }: UserProfileSetupScreenProps) {
  const [displayName, setDisplayName] = useState('');
  const [age, setAge] = useState('');

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">👤</div>
          <h2 className="text-3xl text-gray-700 mb-2">Tell us about you</h2>
          <p className="text-lg text-gray-600">Help us personalize your experience</p>
        </div>
        
        <div className="max-w-sm mx-auto space-y-6">
          <CalmInput
            type="text"
            label="Display Name (Optional)"
            placeholder="How should we call you?"
            value={displayName}
            onChange={setDisplayName}
          />
          
          <CalmInput
            type="number"
            label="Age (Optional)"
            placeholder="Your age"
            value={age}
            onChange={setAge}
          />
          
          <div className="pt-4">
            <CalmButton onClick={onNext} variant="primary" fullWidth>
              Continue 🌸
            </CalmButton>
          </div>
        </div>
      </div>
    </div>
  );
}
