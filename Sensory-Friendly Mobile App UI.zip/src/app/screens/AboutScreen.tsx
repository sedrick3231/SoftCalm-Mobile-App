import React from 'react';
import { Header } from '../components/Header';
import { CalmCard } from '../components/CalmCard';

interface AboutScreenProps {
  onBack: () => void;
}

export function AboutScreen({ onBack }: AboutScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">ℹ️</div>
          <h2 className="text-3xl text-gray-700 mb-2">About Soft Calm</h2>
          <p className="text-lg text-gray-600">Our mission and vision</p>
        </div>
        
        <div className="max-w-md mx-auto space-y-6">
          <CalmCard color="purple">
            <div className="text-center py-6">
              <div className="text-7xl mb-4">🌸</div>
              <h3 className="text-2xl text-gray-700 mb-3">Soft Calm</h3>
              <p className="text-lg text-gray-600">Version 1.0.0</p>
            </div>
          </CalmCard>
          
          <CalmCard color="blue">
            <div className="py-4">
              <h3 className="text-xl text-gray-700 mb-3">💙 Our Mission</h3>
              <p className="text-base text-gray-600 leading-relaxed">
                To create a calm, safe digital space for people with sensory hypersensitivity. 
                We believe technology should adapt to you, not the other way around.
              </p>
            </div>
          </CalmCard>
          
          <CalmCard color="green">
            <div className="py-4">
              <h3 className="text-xl text-gray-700 mb-3">✨ Design Principles</h3>
              <div className="space-y-2 text-base text-gray-600">
                <p>• No intrusive ads or pop-ups</p>
                <p>• No flashing or sudden changes</p>
                <p>• Complete user control</p>
                <p>• Gentle, predictable interactions</p>
                <p>• Minimal cognitive load</p>
              </div>
            </div>
          </CalmCard>
          
          <CalmCard color="pink">
            <div className="py-4">
              <h3 className="text-xl text-gray-700 mb-3">🌟 Unique Features</h3>
              <p className="text-base text-gray-600 leading-relaxed">
                Our Sensory Comfort Mode slider is a one-of-a-kind feature that 
                adjusts brightness, contrast, and visual density with a single control.
              </p>
            </div>
          </CalmCard>
          
          <CalmCard color="yellow">
            <div className="text-center py-6">
              <p className="text-lg text-gray-700 mb-3">
                💚 Thank You
              </p>
              <p className="text-base text-gray-600 leading-relaxed">
                For trusting us with your digital well-being. You matter.
              </p>
            </div>
          </CalmCard>
        </div>
      </div>
    </div>
  );
}
