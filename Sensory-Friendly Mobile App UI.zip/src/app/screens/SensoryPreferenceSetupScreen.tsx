import React from 'react';
import { Header } from '../components/Header';
import { CalmButton } from '../components/CalmButton';
import { CalmCard } from '../components/CalmCard';
import { useSensory } from '../context/SensoryContext';

interface SensoryPreferenceSetupScreenProps {
  onBack: () => void;
  onComplete: () => void;
}

export function SensoryPreferenceSetupScreen({ onBack, onComplete }: SensoryPreferenceSetupScreenProps) {
  const { settings, updateComfortLevel } = useSensory();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">⚙️</div>
          <h2 className="text-3xl text-gray-700 mb-2">Sensory Preferences</h2>
          <p className="text-lg text-gray-600">Set your comfort level</p>
        </div>
        
        <div className="max-w-sm mx-auto space-y-6">
          <CalmCard color="purple">
            <p className="text-lg text-gray-700 mb-4">
              Comfort Level: {settings.comfortLevel}%
            </p>
            <input
              type="range"
              min="0"
              max="100"
              value={settings.comfortLevel}
              onChange={(e) => updateComfortLevel(Number(e.target.value))}
              className="w-full h-3 rounded-full bg-white appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, #C8E6F5 0%, #C8E6F5 ${settings.comfortLevel}%, #fff ${settings.comfortLevel}%, #fff 100%)`,
              }}
            />
            <div className="flex justify-between mt-2 text-sm text-gray-600">
              <span>Minimal 🌙</span>
              <span>Normal 🌞</span>
            </div>
          </CalmCard>
          
          <CalmCard color="green">
            <div className="text-center">
              <p className="text-lg text-gray-700 mb-3">💡 Quick Tip</p>
              <p className="text-base text-gray-600 leading-relaxed">
                Lower levels reduce brightness and visual complexity for maximum comfort.
              </p>
            </div>
          </CalmCard>
          
          <div className="pt-4">
            <CalmButton onClick={onComplete} variant="primary" fullWidth>
              All Set! 🎉
            </CalmButton>
          </div>
        </div>
      </div>
    </div>
  );
}
