import React from 'react';
import { Header } from '../components/Header';
import { CalmCard } from '../components/CalmCard';

interface QuietSpaceScreenProps {
  onBack: () => void;
}

export function QuietSpaceScreen({ onBack }: QuietSpaceScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🏠</div>
          <h2 className="text-3xl text-gray-700 mb-2">Quiet Space</h2>
          <p className="text-lg text-gray-600">Your personal sanctuary</p>
        </div>
        
        <div className="max-w-md mx-auto space-y-6">
          <CalmCard color="purple">
            <div className="text-center py-12">
              <div className="text-8xl mb-6">🌙</div>
              <p className="text-2xl text-gray-700 mb-4">
                You are safe here
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                Take all the time you need. This is your peaceful space.
              </p>
            </div>
          </CalmCard>
          
          <CalmCard color="blue">
            <div className="text-center py-8">
              <p className="text-lg text-gray-700 mb-3">
                🫂 Breathing Exercise
              </p>
              <p className="text-base text-gray-600 leading-relaxed">
                Breathe in slowly for 4 counts, hold for 4, breathe out for 4. Repeat gently.
              </p>
            </div>
          </CalmCard>
          
          <CalmCard color="green">
            <div className="text-center py-8">
              <p className="text-lg text-gray-700 mb-3">
                💙 Gentle Reminder
              </p>
              <p className="text-base text-gray-600 leading-relaxed">
                You're doing great. One moment at a time.
              </p>
            </div>
          </CalmCard>
        </div>
      </div>
    </div>
  );
}
