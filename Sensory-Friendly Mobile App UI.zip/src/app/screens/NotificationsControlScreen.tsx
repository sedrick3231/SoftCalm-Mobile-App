import React from 'react';
import { Header } from '../components/Header';
import { CalmCard } from '../components/CalmCard';
import { useSensory } from '../context/SensoryContext';

interface NotificationsControlScreenProps {
  onBack: () => void;
}

export function NotificationsControlScreen({ onBack }: NotificationsControlScreenProps) {
  const { settings, toggleNotifications } = useSensory();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🔔</div>
          <h2 className="text-3xl text-gray-700 mb-2">Notifications Control</h2>
          <p className="text-lg text-gray-600">Stay in control</p>
        </div>
        
        <div className="max-w-md mx-auto space-y-6">
          <CalmCard color="purple">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-xl text-gray-700 mb-2">📬 Notifications</p>
                <p className="text-base text-gray-600">
                  Gentle reminders only
                </p>
              </div>
              <button
                onClick={toggleNotifications}
                className={`
                  w-16 h-9 rounded-full p-1
                  ${settings.notificationsEnabled ? 'bg-green-300' : 'bg-gray-300'}
                `}
              >
                <div
                  className={`
                    w-7 h-7 rounded-full bg-white shadow-md
                    transition-transform duration-200
                    ${settings.notificationsEnabled ? 'translate-x-7' : 'translate-x-0'}
                  `}
                />
              </button>
            </div>
          </CalmCard>
          
          <CalmCard color="blue">
            <div className="text-center py-6">
              <p className="text-lg text-gray-700 mb-3">
                Current Status
              </p>
              <div className="text-5xl mb-3">
                {settings.notificationsEnabled ? '🔔' : '🔕'}
              </div>
              <p className="text-base text-gray-600">
                {settings.notificationsEnabled 
                  ? 'Gentle notifications enabled'
                  : 'Do not disturb mode'}
              </p>
            </div>
          </CalmCard>
          
          <CalmCard color="green">
            <div className="text-center py-4">
              <p className="text-lg text-gray-700 mb-3">
                💙 Your Comfort First
              </p>
              <p className="text-base text-gray-600 leading-relaxed">
                We never send urgent, loud, or unexpected notifications. Everything is calm and optional.
              </p>
            </div>
          </CalmCard>
        </div>
      </div>
    </div>
  );
}
