import React from 'react';
import { Header } from '../components/Header';
import { CalmButton } from '../components/CalmButton';

interface WelcomeScreenProps {
  onGetStarted: () => void;
  onLogin: () => void;
}

export function WelcomeScreen({ onGetStarted, onLogin }: WelcomeScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header showBack={false} />
      
      <div className="px-6 py-8 flex flex-col items-center">
        <div className="text-8xl mb-6">🌸</div>
        
        <h2 className="text-3xl text-center text-gray-700 mb-4">
          Welcome to Soft Calm
        </h2>
        
        <p className="text-lg text-center text-gray-600 mb-12 max-w-md leading-relaxed">
          A gentle, peaceful app designed for sensory comfort and emotional well-being. 
          Take control of your digital experience. 💙
        </p>
        
        <div className="w-full max-w-sm space-y-4">
          <CalmButton onClick={onGetStarted} variant="primary" fullWidth>
            Get Started 🌟
          </CalmButton>
          
          <CalmButton onClick={onLogin} variant="secondary" fullWidth>
            I Already Have an Account 🔑
          </CalmButton>
        </div>
      </div>
    </div>
  );
}
