import React, { useState } from 'react';
import { Header } from '../components/Header';
import { CalmCard } from '../components/CalmCard';
import { CalmButton } from '../components/CalmButton';

interface MoodTrackerScreenProps {
  onBack: () => void;
}

export function MoodTrackerScreen({ onBack }: MoodTrackerScreenProps) {
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const moods = [
    { id: 'great', emoji: '😊', label: 'Great', color: 'green' as const },
    { id: 'good', emoji: '🙂', label: 'Good', color: 'blue' as const },
    { id: 'okay', emoji: '😐', label: 'Okay', color: 'yellow' as const },
    { id: 'low', emoji: '😔', label: 'Low', color: 'purple' as const },
    { id: 'difficult', emoji: '😢', label: 'Difficult', color: 'pink' as const },
  ];

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => {
      setSaved(false);
      setSelectedMood(null);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">📊</div>
          <h2 className="text-3xl text-gray-700 mb-2">Mood Tracker</h2>
          <p className="text-lg text-gray-600">How are you feeling today?</p>
        </div>
        
        <div className="max-w-md mx-auto space-y-6">
          {!saved ? (
            <>
              <div className="grid grid-cols-2 gap-4">
                {moods.map((mood) => (
                  <CalmCard
                    key={mood.id}
                    color={mood.color}
                    onClick={() => setSelectedMood(mood.id)}
                  >
                    <div className={`
                      text-center py-6
                      ${selectedMood === mood.id ? 'scale-105' : ''}
                    `}>
                      <div className="text-5xl mb-3">{mood.emoji}</div>
                      <p className="text-lg text-gray-700">{mood.label}</p>
                    </div>
                  </CalmCard>
                ))}
              </div>
              
              {selectedMood && (
                <CalmButton onClick={handleSave} variant="primary" fullWidth>
                  Save My Mood 💾
                </CalmButton>
              )}
            </>
          ) : (
            <CalmCard color="green">
              <div className="text-center py-12">
                <div className="text-7xl mb-6">✅</div>
                <p className="text-2xl text-gray-700 mb-4">
                  Saved!
                </p>
                <p className="text-lg text-gray-600">
                  Thank you for sharing. We're here for you.
                </p>
              </div>
            </CalmCard>
          )}
          
          <CalmCard color="blue">
            <div className="text-center py-4">
              <p className="text-lg text-gray-700 mb-3">
                💙 Remember
              </p>
              <p className="text-base text-gray-600 leading-relaxed">
                All feelings are valid. You're doing your best, and that's enough.
              </p>
            </div>
          </CalmCard>
        </div>
      </div>
    </div>
  );
}
