import React from 'react';
import { Header } from '../components/Header';
import { CalmCard } from '../components/CalmCard';

interface DailyCalmActivitiesScreenProps {
  onBack: () => void;
}

export function DailyCalmActivitiesScreen({ onBack }: DailyCalmActivitiesScreenProps) {
  const activities = [
    { id: 1, title: 'Morning Breathing', duration: '5 min', emoji: '🌅', color: 'blue' as const },
    { id: 2, title: 'Gentle Stretching', duration: '10 min', emoji: '🧘', color: 'green' as const },
    { id: 3, title: 'Gratitude Journal', duration: '5 min', emoji: '📝', color: 'yellow' as const },
    { id: 4, title: 'Mindful Walk', duration: '15 min', emoji: '🚶', color: 'purple' as const },
    { id: 5, title: 'Evening Reflection', duration: '10 min', emoji: '🌙', color: 'pink' as const },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">💖</div>
          <h2 className="text-3xl text-gray-700 mb-2">Daily Calm Activities</h2>
          <p className="text-lg text-gray-600">Choose an activity for today</p>
        </div>
        
        <div className="max-w-md mx-auto space-y-4">
          {activities.map((activity) => (
            <CalmCard key={activity.id} color={activity.color}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <span className="text-4xl">{activity.emoji}</span>
                  <div>
                    <h3 className="text-xl text-gray-700">{activity.title}</h3>
                    <p className="text-base text-gray-600">{activity.duration}</p>
                  </div>
                </div>
              </div>
            </CalmCard>
          ))}
        </div>
      </div>
    </div>
  );
}
