import React from 'react';
import { Header } from '../components/Header';
import { CalmCard } from '../components/CalmCard';

interface HelpScreenProps {
  onBack: () => void;
  onNavigate: (screen: string) => void;
}

export function HelpScreen({ onBack, onNavigate }: HelpScreenProps) {
  const helpTopics = [
    { id: 'tips', title: 'Tips for Hypersensitive Users', emoji: '💡', color: 'yellow' as const },
    { id: 'emergency', title: 'Emergency Calm Screen', emoji: '🆘', color: 'pink' as const },
    { id: 'about', title: 'About Soft Calm', emoji: 'ℹ️', color: 'blue' as const },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onBack={onBack} />
      
      <div className="px-6 py-8">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">📚</div>
          <h2 className="text-3xl text-gray-700 mb-2">Help & Guidance</h2>
          <p className="text-lg text-gray-600">We're here to support you</p>
        </div>
        
        <div className="max-w-md mx-auto space-y-4">
          {helpTopics.map((topic) => (
            <CalmCard
              key={topic.id}
              color={topic.color}
              onClick={() => onNavigate(topic.id)}
            >
              <div className="flex items-center gap-4">
                <span className="text-4xl">{topic.emoji}</span>
                <span className="text-xl text-gray-700">{topic.title}</span>
              </div>
            </CalmCard>
          ))}
          
          <CalmCard color="green">
            <div className="text-center py-6">
              <p className="text-lg text-gray-700 mb-3">
                Need Support? 💚
              </p>
              <p className="text-base text-gray-600 leading-relaxed">
                Remember: You can always reach out for help. You're not alone.
              </p>
            </div>
          </CalmCard>
        </div>
      </div>
    </div>
  );
}
