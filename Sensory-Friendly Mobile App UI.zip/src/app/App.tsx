import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SensoryProvider } from './context/SensoryContext';

// Screens
import { SplashScreen } from './screens/SplashScreen';
import { WelcomeScreen } from './screens/WelcomeScreen';
import { LoginScreen } from './screens/LoginScreen';
import { SignUpScreen } from './screens/SignUpScreen';
import { ForgotPasswordScreen } from './screens/ForgotPasswordScreen';
import { UserProfileSetupScreen } from './screens/UserProfileSetupScreen';
import { SensoryPreferenceSetupScreen } from './screens/SensoryPreferenceSetupScreen';
import { HomeScreen } from './screens/HomeScreen';
import { DailyCalmActivitiesScreen } from './screens/DailyCalmActivitiesScreen';
import { FocusModeScreen } from './screens/FocusModeScreen';
import { RelaxationModeScreen } from './screens/RelaxationModeScreen';
import { QuietSpaceScreen } from './screens/QuietSpaceScreen';
import { VisualComfortScreen } from './screens/VisualComfortScreen';
import { SoundControlScreen } from './screens/SoundControlScreen';
import { SensoryComfortModeScreen } from './screens/SensoryComfortModeScreen';
import { NotificationsControlScreen } from './screens/NotificationsControlScreen';
import { MoodTrackerScreen } from './screens/MoodTrackerScreen';
import { HelpScreen } from './screens/HelpScreen';
import { TipsScreen } from './screens/TipsScreen';
import { EmergencyCalmScreen } from './screens/EmergencyCalmScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { AccessibilitySettingsScreen } from './screens/AccessibilitySettingsScreen';
import { AboutScreen } from './screens/AboutScreen';

type Screen = 
  | 'splash'
  | 'welcome'
  | 'login'
  | 'signup'
  | 'forgot-password'
  | 'profile-setup'
  | 'sensory-setup'
  | 'home'
  | 'calm-activities'
  | 'focus-mode'
  | 'relaxation-mode'
  | 'quiet-space'
  | 'visual-comfort'
  | 'sound-control'
  | 'sensory-comfort'
  | 'notifications-control'
  | 'mood-tracker'
  | 'help'
  | 'tips'
  | 'emergency'
  | 'settings'
  | 'accessibility'
  | 'about';

function AppContent() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('splash');
  const [history, setHistory] = useState<Screen[]>(['splash']);
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    // If user logs out, go to welcome
    if (!isAuthenticated && currentScreen !== 'splash' && currentScreen !== 'welcome' && currentScreen !== 'login' && currentScreen !== 'signup' && currentScreen !== 'forgot-password') {
      navigate('welcome');
    }
  }, [isAuthenticated]);

  const navigate = (screen: Screen) => {
    setCurrentScreen(screen);
    setHistory([...history, screen]);
  };

  const goBack = () => {
    if (history.length > 1) {
      const newHistory = history.slice(0, -1);
      setHistory(newHistory);
      setCurrentScreen(newHistory[newHistory.length - 1]);
    }
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'splash':
        return <SplashScreen onComplete={() => navigate('welcome')} />;
      
      case 'welcome':
        return (
          <WelcomeScreen
            onGetStarted={() => navigate('signup')}
            onLogin={() => navigate('login')}
          />
        );
      
      case 'login':
        return (
          <LoginScreen
            onBack={goBack}
            onSuccess={() => navigate('home')}
            onForgotPassword={() => navigate('forgot-password')}
            onSignUp={() => navigate('signup')}
          />
        );
      
      case 'signup':
        return (
          <SignUpScreen
            onBack={goBack}
            onSuccess={() => navigate('profile-setup')}
          />
        );
      
      case 'forgot-password':
        return <ForgotPasswordScreen onBack={goBack} />;
      
      case 'profile-setup':
        return (
          <UserProfileSetupScreen
            onBack={goBack}
            onNext={() => navigate('sensory-setup')}
          />
        );
      
      case 'sensory-setup':
        return (
          <SensoryPreferenceSetupScreen
            onBack={goBack}
            onComplete={() => navigate('home')}
          />
        );
      
      case 'home':
        return <HomeScreen onNavigate={navigate} />;
      
      case 'calm-activities':
        return <DailyCalmActivitiesScreen onBack={goBack} />;
      
      case 'focus-mode':
        return <FocusModeScreen onBack={goBack} />;
      
      case 'relaxation-mode':
        return <RelaxationModeScreen onBack={goBack} />;
      
      case 'quiet-space':
        return <QuietSpaceScreen onBack={goBack} />;
      
      case 'visual-comfort':
        return <VisualComfortScreen onBack={goBack} />;
      
      case 'sound-control':
        return <SoundControlScreen onBack={goBack} />;
      
      case 'sensory-comfort':
        return <SensoryComfortModeScreen onBack={goBack} />;
      
      case 'notifications-control':
        return <NotificationsControlScreen onBack={goBack} />;
      
      case 'mood-tracker':
        return <MoodTrackerScreen onBack={goBack} />;
      
      case 'help':
        return <HelpScreen onBack={goBack} onNavigate={navigate} />;
      
      case 'tips':
        return <TipsScreen onBack={goBack} />;
      
      case 'emergency':
        return <EmergencyCalmScreen onBack={goBack} />;
      
      case 'settings':
        return <SettingsScreen onBack={goBack} onNavigate={navigate} />;
      
      case 'accessibility':
        return <AccessibilitySettingsScreen onBack={goBack} />;
      
      case 'about':
        return <AboutScreen onBack={goBack} />;
      
      default:
        return <WelcomeScreen onGetStarted={() => navigate('signup')} onLogin={() => navigate('login')} />;
    }
  };

  return (
    <div className="min-h-screen">
      {renderScreen()}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <SensoryProvider>
        <AppContent />
      </SensoryProvider>
    </AuthProvider>
  );
}
