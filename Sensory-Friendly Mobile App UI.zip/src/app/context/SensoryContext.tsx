import React, { createContext, useContext, useState, ReactNode } from 'react';

interface SensorySettings {
  comfortLevel: number; // 0-100, 0 = minimum stimulation, 100 = normal
  brightness: number; // 0-100
  contrast: number; // 0-100
  visualDensity: number; // 0-100
  soundEnabled: boolean;
  notificationsEnabled: boolean;
}

interface SensoryContextType {
  settings: SensorySettings;
  updateComfortLevel: (level: number) => void;
  updateBrightness: (level: number) => void;
  updateContrast: (level: number) => void;
  updateVisualDensity: (level: number) => void;
  toggleSound: () => void;
  toggleNotifications: () => void;
}

const SensoryContext = createContext<SensoryContextType | undefined>(undefined);

export function SensoryProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<SensorySettings>({
    comfortLevel: 50,
    brightness: 50,
    contrast: 50,
    visualDensity: 50,
    soundEnabled: false,
    notificationsEnabled: false,
  });

  const updateComfortLevel = (level: number) => {
    setSettings(prev => ({
      ...prev,
      comfortLevel: level,
      brightness: level,
      contrast: level,
      visualDensity: level,
    }));
  };

  const updateBrightness = (level: number) => {
    setSettings(prev => ({ ...prev, brightness: level }));
  };

  const updateContrast = (level: number) => {
    setSettings(prev => ({ ...prev, contrast: level }));
  };

  const updateVisualDensity = (level: number) => {
    setSettings(prev => ({ ...prev, visualDensity: level }));
  };

  const toggleSound = () => {
    setSettings(prev => ({ ...prev, soundEnabled: !prev.soundEnabled }));
  };

  const toggleNotifications = () => {
    setSettings(prev => ({ ...prev, notificationsEnabled: !prev.notificationsEnabled }));
  };

  return (
    <SensoryContext.Provider
      value={{
        settings,
        updateComfortLevel,
        updateBrightness,
        updateContrast,
        updateVisualDensity,
        toggleSound,
        toggleNotifications,
      }}
    >
      {children}
    </SensoryContext.Provider>
  );
}

export function useSensory() {
  const context = useContext(SensoryContext);
  if (!context) {
    throw new Error('useSensory must be used within SensoryProvider');
  }
  return context;
}
